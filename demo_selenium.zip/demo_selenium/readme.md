# Install dependencies
pip install -r requirements.txt

# Run single test
pytest -v tests/test_simple.py

# Run dengan output detail
pytest -v -s tests/test_simple.py


tests/test_simple.py::test_website_accessibility PASSED
✅ Website accessible: https://mathsteam.id/login
✅ Page title: MathsTeam - Login